document.getElementById("connect").onclick = async function () {
  if (window.solana && window.solana.isPhantom) {
    try {
      const resp = await window.solana.connect();
      alert("Conectado: " + resp.publicKey.toString());
    } catch (err) {
      console.error("Erro ao conectar:", err);
    }
  } else {
    alert("Phantom Wallet não encontrada!");
  }
};
